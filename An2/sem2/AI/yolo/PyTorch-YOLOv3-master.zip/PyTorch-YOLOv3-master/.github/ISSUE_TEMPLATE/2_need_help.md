---
name: "⁉️ Need help?"
about: "Get help with using or improving our software"
title: ''
labels: ''
assignees: ''
---

## What I'm trying to do
<!--- Please describe what you're trying to do so we know what your problem is about. -->

## What I've tried
<!--- If you tell us, what you already tried or what documentation you already read, we are able to help you better by not pointing to information you already know. -->

## Additional context
<!--- If there's more to say, feel free to do so :) -->
